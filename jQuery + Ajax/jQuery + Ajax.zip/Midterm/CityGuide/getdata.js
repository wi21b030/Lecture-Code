/*ToDo*/

$(document).ready(function () {
    $.ajax({
        method: "GET",
        url: "./traveldata.json",
        dataType: "json",
        success: function (response) {
            console.log(response);
            ladeKarte(response);
        },
        error: function () {
            $('#mainContainer').html('<div class="alert alert-danger text-center" role="alert">Data could not be loaded!</div>');
        }
    });
});

function ladeKarte(response) {
    for (let i in response) {
        // create marker image, source, class, css, animation and add to map span
        var marker = response[i];
        var markerEl = $('<img>');
        markerEl.attr("src", "./img/marker.png");
        markerEl.attr("class", "location");
        markerEl.css("left", marker.location.x + "px")
        markerEl.css("top", marker.location.y + "px")
        markerEl.attr('title', marker.poi);
        markerEl.hide().fadeIn(1000)
        $('#streetmap').append(markerEl);

        // create infobox div with name, description, class, css and hide
        var infoEl = $('<div>');
        var nameEl = $('<p>').html('<strong>' + marker.poi + '</strong>');
        var descEl = $('<p>').html(marker.location.info);
        infoEl.append(nameEl, descEl);
        infoEl.addClass('info');
        infoEl.css("left", (parseFloat(marker.location.x) + 85) + "px");
        infoEl.css("top", marker.location.y + "px");
        infoEl.hide();

        // add on-click loadInfo function
        $('#streetmap').append(infoEl);
        markerEl.on('click', function () {
            loadInfo($(this));
        });
    }
    // Bonus: add border to map
    var map = $('#streetmap');
    map.css({
        border: "solid black",
        margin: "auto",
    })
}

function loadInfo(marker) {
    // show info box matching id, toggle 500ms
    var index = $('.location').index(marker);
    $('.info').not($('.info').eq(index)).hide();
    $('.info').eq(index).toggle(500);

    // Bonus: hide infobox when mouse leaves marker
    marker.on('mouseleave', function () {
        $('.info').eq(index).hide(500);
    });
}


