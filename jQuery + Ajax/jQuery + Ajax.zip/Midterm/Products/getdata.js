$(document).ready(function () {
    $.ajax({
        method: "GET",
        url: "./products.json",
        dataType: "json",
        success: function (response) {
            loadProducts(response);
        },
        error: function () {
            $('#output').html('<p style="color:red">Data could not be loaded</p>')
        }
    })
});

function loadProducts(response) {
    console.log(response)
    for (let i in response) {
        var product = response[i];

        // create DIV-Element with dataset
        var productEl = $('<div>');
        productEl.data({
            detail: product.detail,
            price: product.price,
            stock: product.stock
        });

        // set class 'greyline' alternatingly
        if (i % 2 == 0) {
            productEl.attr('class', 'greyline');
        }

        // if stock of product bigger than 0 then add click event-handler
        // BONUS: added color for easier experience
        if (product.stock > 0) {
            productEl.css('color', 'green');
            productEl.on('click', function () {
                showdetails($(this));
            });
        } else {
            productEl.css('color', 'red');
        }
        productEl.text(product.name);
        $('#output').append(productEl);
    }

    // slideDown animation
    $('#output').hide().slideDown(350);

    // BONUS: add border to output div
    $('#output').css('border', 'solid black');
}

function showdetails(product) {
    // change h1
    $('h1').text(product.text());

    // create div for detailed list of info
    var detailedList = $('<div>');
    detailedList.html('<p>' + product.data('detail') + '</p>' +
        '<p>Price: ' + product.data('price') + '</p>' +
        '<p>Stock: ' + product.data('stock') + '</p>');

    // add animation for fadeIn
    $('#selected').hide().html(detailedList).fadeIn(200);

    // add animation for slideUp
    $('#output').slideUp(300);

    // BONUS: add button to show full list again
    var resetButton = $('<btn>');
    resetButton.attr({
        type: "button",
        class: "btn btn-primary"
    });
    resetButton.text('Show all products again');
    resetButton.on('click', function () {
        $('h1').text('Products');
        $('#output').slideDown(350);
        $('#selected').fadeOut(200);
    });
    $('#selected').append(resetButton);
}