/*ToDo*/

// Settings:
let restServer: string = "http://localhost:80/webtechnologien/SM2021/EXAM_WebScripting_WorldClock/api/timezones.php";

/*$.getJSON(restServer,
    { 'method': 'queryPersonByDept', 'param': 'Faculty' },
    function (data: object) {
        $('#mainpart').text(JSON.stringify(data));
    });*/

function loadData() {

    $.ajax({
        method: "GET",
        url: restServer,
        cache: false,
        data: {
            method: "",
            param: "",
        },
        dataType: "json",

        success: function (data) {
            let $quellZeitzone = $('#quellZeitzone');
            $quellZeitzone.empty();
            for (var i = 0; i < data.length; i++) {
                $quellZeitzone.append('<option value=' + data[i] + '>' + data[i] + '</option>');
            }

            let $zielZeitzone = $('#zielZeitzone');
            $zielZeitzone.empty();
            for (var i = 0; i < data.length; i++) {
                $zielZeitzone.append('<option value=' + data[i] + '>' + data[i] + '</option>');
            }
            
        }

    });
}

/**
 *  {
 *     "date": "23.04.2021 15:00:00",
 *	   "tzsource": "Europe/Vienna",
 *     "tztarget": "Europe/London"
 *  }
 */
function convertData() {

    let $datetimeLocal = $('#datetimeLocal').text;
    let $zielZeitzone = $('#zielZeitzone').text;
    let $quellZeitzone = $('#quellZeitzone').text;

    $.ajax({
        method: "POST",
        url: restServer,
        cache: false,
        data: {
            date: $datetimeLocal,
            tzsource: $zielZeitzone,
            tztarget: $quellZeitzone,
        },
        dataType: "json",

        success: function (data) {
            $('#result').text(JSON.stringify(data));
        }

    });
}